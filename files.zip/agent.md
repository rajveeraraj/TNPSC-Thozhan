# AGENT.md – Kadai Kanakku

Instructions for AI coding agents (Claude Code, Cursor, Copilot, etc.) working on this repo.

---

## 1. Project Overview

**Kadai Kanakku** – chinna kadai owners-ku kadan (credit) tracker + daily sales app. Pending baaki-ku WhatsApp reminder.

- **Users:** Small shop owners (Tamil-first, low tech comfort)
- **Platform:** Web app (React PWA) + Laravel REST API
- **Spec:** See `kadai-kanakku.md` for full features, MVP, and screens

---

## 2. Tech Stack

| Layer | Tech |
|---|---|
| Backend | Laravel 11 (PHP 8.2+), MySQL 8, Sanctum |
| Multi-tenancy | `stancl/tenancy` (database-per-shop) |
| Frontend | React + Vite + TypeScript (PWA) |
| Styling | Tailwind CSS (mobile-first) |
| State | TanStack Query (server), Zustand (app) |
| Offline | Dexie (IndexedDB) + Service Worker (`vite-plugin-pwa`) |
| Auth | Mobile number (username) + password. No OTP in MVP |
| WhatsApp | MVP: `wa.me` deep link. Phase 2: WhatsApp Business Cloud API |
| Queue | Redis (reminders, backups, tenant migrations) |

---

## 3. Repo Structure

```
kadai-kanakku/
├── backend/        Laravel API
├── web/            React PWA
├── docs/           agent.md, kadai-kanakku.md
└── README.md
```

### Backend
```
backend/
├── app/
│   ├── Http/
│   │   ├── Controllers/Api/V1/
│   │   │   AuthController, DashboardController, CustomerController,
│   │   │   TransactionController, SaleController, DayClosingController,
│   │   │   ReminderController, ReportController, SyncController
│   │   ├── Middleware/InitializeTenancyByToken.php
│   │   ├── Requests/       Form Requests
│   │   └── Resources/      API Resources
│   ├── Models/
│   │   ├── Central/        Shop, ShopStat
│   │   └── Tenant/         Customer, Transaction, Sale, DayClosing, Reminder
│   ├── Services/           ShopSignupService, LedgerService, SyncService,
│   │                       ReminderService, ReportService
│   ├── Jobs/               CreateTenantDatabase, MigrateTenantDatabase,
│   │                       BackupTenantDatabase, UpdateShopStats
│   └── Providers/TenancyServiceProvider.php
├── database/migrations/          central: shops, personal_access_tokens
├── database/migrations/tenant/   customers, transactions, sales,
│                                 day_closings, reminders
├── routes/api.php                /api/v1/auth/*  (central)
├── routes/tenant.php             /api/v1/*       (tenant, token required)
├── config/tenancy.php            prefix: "store_"
└── tests/Feature/
```

### Frontend
```
web/
├── public/manifest.webmanifest, icons/
├── src/
│   ├── main.tsx, App.tsx
│   ├── routes/             router, ProtectedRoute
│   ├── core/
│   │   ├── api/            axios client, token interceptor
│   │   ├── i18n/           ta.json, en.json (Tamil default)
│   │   ├── theme/          big fonts, colors
│   │   ├── utils/          currency, date, phone format
│   │   └── components/     BigButton, AmountText, Modal, EmptyState
│   ├── db/dexie.ts         IndexedDB tables
│   ├── sync/syncManager.ts push pending, pull delta
│   ├── store/              Zustand (auth, shop, sync status)
│   └── features/
│       ├── auth/ dashboard/ customers/ transactions/
│       ├── sales/ reminders/ reports/ settings/
│       └── each feature: api.ts, hooks.ts, components/, pages/
├── vite.config.ts          vite-plugin-pwa
└── tailwind.config.js
```

---

## 4. Multi-Tenancy (CRITICAL)

- **One mobile number = one shop = one account.** `shops.mobile` is `UNIQUE`.
- **Database per shop.** Tenant DB name: `store_{shop_id}` (e.g. `store_1`, `store_2`).
- **Central DB** (`kadai_central`): `shops` (id, mobile UNIQUE, name, password, db_name, status), `shop_stats`, tokens.
- **Tenant DB** (`store_{shop_id}`): customers, transactions, sales, day_closings, reminders.
- One shop's data must NEVER be readable from another shop's DB.

### Request flow
1. Login: mobile + password → Sanctum token (contains `shop_id`)
2. Every tenant request: middleware reads token → `shop_id` → switches to `store_{shop_id}`
3. Controllers/models then only see that shop's data

### Signup flow
1. Validate mobile (10 digits, store as `+91XXXXXXXXXX`), reject if exists
2. Create central `shops` row (hashed password)
3. Queue job: create DB `store_{id}` + run tenant migrations
4. Return token

### Rules
- DB creation uses a limited MySQL user (CREATE + GRANT only), never root.
- Tenant migrations must be backward-compatible (add columns, never drop in the same release).
- Track `migrated_version` per shop; failed shops are retried by queue.
- Per-shop nightly backup (`mysqldump` → S3).

---

## 5. Authentication

- Login = **mobile number + password**.
- Password: bcrypt (Laravel default), min 6 chars.
- Rate limit: 5 failed attempts → 15 min lock (per mobile + IP).
- Token: Sanctum Bearer token.
- Forgot password (MVP): manual reset by admin via support WhatsApp. OTP reset is Phase 2.
- Never log passwords or tokens.

---

## 6. Terminology (IMPORTANT)

Use **Tamil words** in UI. Do NOT use "Udhar" anywhere.

| Concept | UI Text | Code name |
|---|---|---|
| Credit given | Kadan Koduthen | `credit` |
| Payment received | Panam Vandhuchu | `payment` |
| Pending balance | Baaki | `balance` |
| Customer | Vaadikkaiyaalar | `customer` |
| Shop | Kadai | `shop` |
| Sales | Viyaabaaram | `sale` |

- Code, DB columns, API fields → English.
- UI strings → i18n files (`ta.json`, `en.json`), never hardcoded.

---

## 7. Core Rules

### General
- Keep code simple. Users are non-technical, so is the UX.
- MVP first. No Phase 2/3 features unless asked.
- No new dependencies without clear reason.
- Small, focused changes. One feature per PR.

### Money
- Store amounts as integers in paise (or `DECIMAL(12,2)`). Never float.
- Balance = sum(credit) − sum(payment), computed from transactions.
- Never hard-delete transactions. Soft delete + audit log.
- Transactions are append-only; corrections via adjustment entries.

### Offline-first
- Web writes to IndexedDB (Dexie) first, syncs when online.
- Every record has client-generated `uuid`, `updated_at`, `synced_at`.
- Server rejects duplicate `uuid` (idempotent sync).
- MVP: one device per shop.
- Show sync status: ✅ synced / 🕒 pending.

### Security
- Validate all input with Laravel Form Requests.
- CORS: allow only the web app origin.
- Never log phone numbers, passwords, tokens.
- HTTPS only in production.

---

## 8. Backend Guidelines

- PSR-12, Laravel conventions. Format with `./vendor/bin/pint`.
- Thin controllers, logic in Service classes.
- Form Requests + API Resources.
- Avoid N+1 (`with()`).
- Migrations only; never edit DB manually.
- API versioned `/api/v1/...`
- Response format:

```json
{ "success": true, "message": "Saved", "data": {} }
```

- Feature tests for every endpoint (Pest/PHPUnit), especially balance logic and tenant isolation.

### API groups
```
POST   /api/v1/auth/signup
POST   /api/v1/auth/login
POST   /api/v1/auth/logout
GET    /api/v1/dashboard
CRUD   /api/v1/customers
GET    /api/v1/customers/{id}/transactions
POST   /api/v1/transactions          (type: credit | payment)
CRUD   /api/v1/sales
POST   /api/v1/day-closings
GET    /api/v1/reports/{type}
POST   /api/v1/reminders
POST   /api/v1/sync
```

---

## 9. Frontend Guidelines

- Mobile-first. Big buttons, large text, few fields per screen.
- Max 3 taps to add a kadan entry.
- Tamil default language.
- Baaki: **red** = customer owes, **green** = advance.
- Indian number format: `₹1,25,000`.
- Works offline (PWA). No blocking spinners for local actions.
- PIN lock (no biometric on web).
- Forms: React Hook Form + Zod.
- Feature-first folders, no cross-feature imports except via `core/`.

### PWA limits to remember
- No phone contacts import (manual add / CSV).
- Browser data clear = local data loss, so cloud sync + backup matter.
- Limited push notifications on iOS.

---

## 10. WhatsApp Reminder

MVP deep link:

```
https://wa.me/91XXXXXXXXXX?text=<url-encoded message>
```

Default template:

```
Vanakkam {customer_name}, {shop_name}-la ungal baaki ₹{amount}. Time irukkum podhu kodukkavum. Nandri 🙏
```

- Owner can edit templates.
- Log every reminder in `reminders`.
- No auto-send in MVP.
- Auto reminders via Business API in premium plan (Phase 2).

---

## 11. Database Conventions

- Tables: plural snake_case. Columns: snake_case.
- Every table: `id`, `uuid`, `created_at`, `updated_at`, `deleted_at`.
- Indexes on `customer_id`, `date`, `uuid`.
- Tenant tables: `customers`, `transactions`, `sales`, `day_closings`, `reminders`.
- Central tables: `shops`, `shop_stats`, `personal_access_tokens`.

---

## 12. Known Risks & Solutions

| Risk | Solution |
|---|---|
| Migration across many `store_*` DBs | Queue batch, retry, `migrated_version`, test on 1 shop first |
| Too many DBs / cross-shop reports | `shop_stats` in central DB, nightly update job |
| Offline sync conflicts | uuid idempotency, append-only transactions, one device per shop |
| Forgot password | Manual reset in MVP, OTP later |
| Unverified mobile numbers | Accept in MVP, add OTP verify later |
| Data loss (browser clear) | Auto cloud sync, daily backup, export PDF/Excel |
| Trust / privacy | Tamil privacy policy, PIN lock, data export |
| Competition (Khatabook, OkCredit) | Tamil-first UI, local onboarding in Pudukkottai, WhatsApp support |

---

## 13. Git & Workflow

- Branches: `feature/<name>`, `fix/<name>`, `chore/<name>`
- Conventional Commits: `feat:`, `fix:`, `docs:`, `refactor:`, `test:`
- Before commit:
  - Backend: `php artisan test` · `./vendor/bin/pint`
  - Web: `npm run lint` · `npm run test` · `npm run build`
- Never commit `.env`, keys, build output.

---

## 14. Do / Don't

**Do**
- Read `kadai-kanakku.md` before building a feature.
- Ask when requirements are unclear.
- Test money, balance, and tenant isolation.
- Keep Tamil UI text short and simple.

**Don't**
- Don't use "Udhar" in UI.
- Don't use float for money.
- Don't hard-delete financial records.
- Don't add features outside MVP scope.
- Don't refactor unrelated code.
- Don't let one shop's data reach another shop.

---

## 15. Current Focus (MVP)

1. Laravel + tenancy setup (`store_{shop_id}`)
2. Signup/login (mobile + password), unique mobile
3. Customers CRUD
4. Kadan & payment entries + ledger
5. Dashboard (total baaki, today's sales)
6. Daily sales + day close
7. WhatsApp reminder (`wa.me`)
8. Tamil + English i18n
9. Offline sync + backup
10. Testing (Section 16): backend, frontend, e2e, security
11. Pilot with 10 kadai in Pudukkottai

---

## 16. Testing (REQUIRED before every release)

Agents must write and run tests for every feature. No feature is "done" until tests pass.

### 16.1 Backend tests (Pest / PHPUnit)

Run: `php artisan test`

**Auth**
- Signup success → shop row created, `store_{id}` DB created, tenant tables migrated, token returned
- Signup with existing mobile → rejected (unique)
- Invalid mobile format (not 10 digits) → rejected
- Login success / wrong password → 401
- 5 failed logins → locked 15 min
- Logout revokes token

**Tenant isolation (MOST IMPORTANT)**
- Shop A token cannot read Shop B customers / transactions / sales
- Shop A creates data → `store_B` has zero rows
- Request without token → 401, no DB switch
- Tampered / expired token → 401
- Two shops with same customer mobile → no clash

**Customers**
- Create, update, soft delete, search, filter (pending / overdue)
- Duplicate customer mobile inside one shop → warn or reject

**Transactions / ledger**
- Kadan adds to balance, payment reduces balance
- Balance = sum(credit) − sum(payment), exact (no float errors)
- Partial payment, overpayment (shows advance)
- Delete is soft; audit log entry created
- Same `uuid` sent twice → saved once (idempotent)

**Sales & day close**
- Sale entry (cash / UPI / kadan split) totals correct
- Day closing: opening + sales − expenses = closing cash check
- One closing per day

**Reminders**
- `wa.me` link built with `91` + number, URL-encoded Tamil text
- Reminder logged in `reminders`

**Sync**
- Push pending records → saved
- Pull delta using `last_synced_at` → only newer records
- Conflict: last-write-wins for customers, append-only for transactions

**Multi-tenancy ops**
- `tenants:migrate` runs on all `store_*` DBs
- One shop migration fails → others continue, failure logged, retried
- Backup job creates dump per shop

### 16.2 Frontend tests (Vitest + React Testing Library)

Run: `npm run test`

- Login / signup form validation (mobile, password)
- Add kadan: 3 taps, amount formatting `₹1,25,000`
- Baaki colors: red (owes), green (advance)
- Tamil / English switch, no hardcoded strings
- Offline: add entry with network off → saved in IndexedDB, shows 🕒 pending
- Back online → auto sync → ✅ synced
- Protected routes redirect to login

### 16.3 End-to-end tests (Playwright)

Run: `npx playwright test` (use mobile viewport 360x640)

1. Signup → login → add customer → add kadan → add payment → balance correct
2. Add daily sale → close day → summary correct
3. Bulk remind → WhatsApp link opens with right message
4. Two shops in parallel → data never mixes
5. Go offline → add 5 entries → online → all synced once

### 16.4 PWA checks

- Lighthouse PWA score: pass (installable, offline, manifest, service worker)
- Lighthouse performance on slow 3G: load < 4s
- Works on low-end Android (2GB RAM) + Chrome
- "Add to Home Screen" works

### 16.5 Security checks

- SQL injection / XSS attempts on all inputs
- Rate limiting on login
- Password stored as bcrypt hash
- No tokens / passwords in logs
- CORS only allows the web origin
- `.env` not in git
- Tenant DB user has access to own DB only

### 16.6 Manual QA checklist (before pilot)

- [ ] Signup with new mobile works
- [ ] Same mobile signup shows "already registered"
- [ ] Login / logout / auto-login
- [ ] Add customer, edit, search
- [ ] Add kadan, add payment, balance correct
- [ ] Daily sales + day close
- [ ] WhatsApp reminder opens with Tamil message
- [ ] Offline add + sync
- [ ] Tamil UI: no cut-off text, readable fonts
- [ ] Works on 2 real phones, 2 different shops, data separate
- [ ] Backup + restore tested on one shop
- [ ] Export PDF / Excel opens correctly

### 16.7 Pilot testing

- 5 kadai owners in Pudukkottai, 1–2 weeks
- Track: entries/day, crashes, confusing screens, sync failures
- Collect feedback via WhatsApp group
- Fix top 5 issues before opening to more shops

### 16.8 Definition of Done (per feature)

- [ ] Code follows this file's rules
- [ ] Backend feature tests pass
- [ ] Tenant isolation test included
- [ ] Frontend test added
- [ ] Works offline (if data feature)
- [ ] Tamil strings added to i18n
- [ ] Linter + formatter clean (`pint`, `npm run lint`)
- [ ] No new float money / hard delete / "Udhar" text

### 16.9 CI (GitHub Actions)

On every push / PR:
1. Backend: `composer install` → `pint --test` → `php artisan test`
2. Web: `npm ci` → `npm run lint` → `npm run test` → `npm run build`
3. Block merge if any step fails

---

## 17. Dashboard, CRM, Masters & Categories

Full details in `kadai-kanakku.md` Section 12. Agent rules:

### Modules
- **Dashboard:** cards (baaki, today sales, kadan given, vasool, cash in hand, overdue), top 5 baaki, overdue list, 7-day sales chart. Data comes from one `/api/v1/dashboard` call (cached, offline-friendly).
- **CRM:** customer 360 profile, category + tags, notes, credit limit warning, promise-to-pay, reminder history. P2: payment behaviour score, follow-ups, groups, bulk WhatsApp.
- **Masters:** shop profile, customer category, payment mode, reminder template (MVP). Product, unit, expense category, supplier (P2).
- **Categories:** customer, product, expense. Name + color + icon + active flag. Never hard-delete a category in use, only deactivate.
- **Super Admin:** separate panel on central DB. Shops list, reset password, block, change mobile, retry migration.

### Seed data (auto-create on signup, inside `store_{id}`)
- Customer categories: Regular, VIP, New, Wholesale, Risky
- Payment modes: Cash, UPI, Card
- Reminder templates: default Tamil template
- Product / expense categories: seeded in P2 by shop type

### Extra API groups
```
GET/POST/PUT/DELETE  /api/v1/customer-categories
GET/POST/PUT/DELETE  /api/v1/payment-modes
GET/POST/PUT/DELETE  /api/v1/reminder-templates
POST                 /api/v1/customers/{id}/notes
POST                 /api/v1/customers/{id}/promises
GET                  /api/v1/trash            POST /api/v1/trash/{id}/restore
GET                  /api/v1/audit-logs
# Super admin (central, admin guard)
GET    /admin/shops
POST   /admin/shops/{id}/reset-password
POST   /admin/shops/{id}/block
POST   /admin/shops/{id}/retry-migration
```

### Rules
- Dashboard numbers must equal ledger totals. Add test comparing dashboard vs raw transactions.
- Category / master changes sync offline like other records (uuid).
- Every edit/delete on customers and transactions writes `audit_logs`.
- Admin routes use a separate `admins` table and guard. Never reuse shop tokens.
- Admin password reset: generate temp password, show once, force change on next login.

### Tests to add (extends Section 16)
- Dashboard totals match transactions
- Category in use cannot be deleted, only deactivated
- Seed data created on signup
- Credit limit exceeded → warning returned
- Promise-to-pay due today appears in overdue list
- Trash restore brings back record + balance
- Admin cannot be accessed with a shop token, shop token cannot call `/admin/*`

---

## 18. ERP Modules (Phase 2 / 3 – DO NOT build in MVP)

Full list in `kadai-kanakku.md` Section 13. Build only when explicitly asked, one module at a time.

### Modules
Inventory, Purchase & Suppliers, Billing/POS, Accounting (cash book, P&L), Staff/HR, Roles & Permissions, Multi-shop, ERP reports, Integrations, Subscription.

### Architecture rules
- Each ERP module is **optional**: feature flag per shop in `shop_settings` (`modules: ["inventory","billing"]`). Hide menu + block API if off.
- Backend: one folder per module: `app/Modules/Inventory`, `Billing`, `Purchase`, `Accounting`, `Staff`. Each has Controllers, Services, Models, Requests, routes.
- Frontend: one feature folder per module, lazy-loaded.
- Tenant migrations per module in `database/migrations/tenant/<module>/`.
- Billing creates ledger entries: unpaid part of an invoice becomes a `credit` transaction for that customer (so Baaki stays correct).
- Purchase unpaid part becomes supplier payable.
- Customer baaki and supplier payable must always reconcile with invoices/purchases and payments.

### Stock rules
- `stock_movements` is **append-only**. Current stock = sum(in) − sum(out) ± adjustments. Never edit stock qty directly.
- Cost method: weighted average (default). Store cost on each sale for correct profit.
- Negative stock: allowed with warning (small shops often bill before entering purchase). Configurable per shop.
- Sale / purchase edit or delete reverses stock via new movement entries.
- Units: store in base unit, convert on display.

### Billing rules
- Bill number: unique per shop, sequence per year, no gaps for finalized bills. Cancel = status `cancelled`, never delete.
- Totals computed on server; client total is only a preview.
- Money in paise, rounding rule: round-off line item, not silent change.
- GST (P3): store tax rate, HSN, CGST/SGST split per line.
- Printing: thermal 58mm layout is the default template.

### Accounting rules
- Cash book is derived from transactions, sales, expenses, supplier payments. No manual edit of balances.
- P&L = sales − cost of goods sold − expenses. Test with known fixtures.
- Day close must match cash book.

### Roles (P3)
- Staff login lives inside the shop's `store_{id}` DB (`shop_users`). Owner stays in central `shops`.
- Permission check in middleware + policy, not only hidden UI.
- Cashier cannot see profit, purchase price, or delete bills.

### Extra API groups (when built)
```
CRUD  /api/v1/products, /categories/products, /units
GET   /api/v1/stock, /stock/ledger/{product}
POST  /api/v1/stock/adjust
CRUD  /api/v1/suppliers
CRUD  /api/v1/purchases        POST /api/v1/suppliers/{id}/payments
CRUD  /api/v1/invoices         POST /api/v1/invoices/{id}/return
GET   /api/v1/cash-book, /day-book, /reports/profit-loss
CRUD  /api/v1/staff, /roles
```

### ERP tests (add when module is built)
- Stock after purchase / sale / return / adjustment is exact
- Invoice with part payment creates correct customer baaki
- Cancelled invoice reverses stock and baaki
- Weighted average cost updates correctly, profit report matches fixtures
- Supplier payable reconciles with purchases − payments
- Module off → menu hidden and API returns 403
- Cashier role cannot access profit, purchase price, delete bill
- Bill numbers unique and gapless per shop per year
- Two shops: stock and invoices never mix
