# Kadai Kanakku – Product Spec

**Tagline:** Chinna kadai-ku simple kadan & sales kanakku.
**Target users:** Maligai kadai, tea kadai, tailor, medical shop, hardware, vegetable shop – small shop owners (Tamil-first, low tech comfort).
**Platform:** Android app (Flutter / React Native) + Laravel REST API + MySQL.

---

## 1. Problem

- Kadan kanakku notebook-la ezhuthuvaanga → lost / mistake / dispute.
- Customer-ku yaaru evlo baaki nu ninaivu illa.
- Daily sales & profit theriyaadhu.
- Dues-ah kekka thayakkam → payment delay.

## 2. Goals

- 30 seconds-la oru kadan entry add pannanum.
- Pending dues-ku automatic WhatsApp reminder.
- Daily sales oru nodi-la paakkanum.
- Tamil UI, big buttons, offline support.

---

## 3. Full Functionality

### 3.1 Auth & Account
- Mobile number + OTP login
- Shop profile (name, owner, address, logo, UPI ID)
- Language: Tamil / English
- Optional PIN / fingerprint lock

### 3.2 Customer Management
- Add / edit / delete customer (name, phone, address, notes)
- Import from phone contacts
- Customer-wise balance (To Receive / Advance)
- Credit limit per customer
- Customer tags (Regular, Risky, VIP)
- Search & filter (pending, overdue, highest due)

### 3.3 Kadan (Credit) Ledger
- Add **Kadan Koduthen** (credit given) – amount, item note, date, photo of bill
- Add **Panam Vandhuchu** (payment received) – amount, mode (Cash / UPI / Partial)
- Running balance per customer
- Due date per entry
- Edit / delete with audit log
- Customer statement (PDF / image share)

### 3.4 Daily Sales
- Quick sales entry (cash / UPI / kadan split)
- Daily total sales, cash in hand, kadan given, kadan collected
- Opening & closing cash
- Day close summary
- Calendar view of past days

### 3.5 Expenses (Phase 2)
- Daily expense entry (rent, stock purchase, EB bill, salary)
- Category-wise expenses
- Profit = Sales − Expenses

### 3.6 WhatsApp Reminders
- One-tap "Remind" button per customer
- Pre-filled Tamil message template (editable)
- Bulk reminder for all overdue customers
- Auto reminder schedule (weekly / on due date) – via WhatsApp Business API (Phase 2)
- Reminder history log
- Send statement / payment receipt on WhatsApp

### 3.7 Reports
- Daily / weekly / monthly sales
- Total kadan outstanding
- Top 10 pending customers
- Collection report
- Export PDF / Excel

### 3.8 Notifications
- Due today alert
- Overdue alert
- Daily "close the day" reminder (night)
- Weekly summary

### 3.9 Backup & Sync
- Offline-first (local DB, sync when online)
- Cloud backup & restore on new phone
- Multi-device (Phase 3)

### 3.10 Extras (Later)
- Staff accounts with roles
- Stock / inventory
- Voice entry in Tamil ("Murugan-ku 200 kadan")
- UPI QR on statements
- Multiple shops
- Subscription / premium plan

---

## 4. MVP Scope (Version 1.0 – 4 to 6 weeks)

### Must have
- [ ] OTP login + shop setup
- [ ] Add / edit customers
- [ ] Kadan given & payment received entries
- [ ] Customer-wise balance & ledger
- [ ] Dashboard: total to receive, today's sales
- [ ] Daily sales entry + day summary
- [ ] WhatsApp reminder (one-tap, `wa.me` link with pre-filled Tamil text)
- [ ] Tamil + English UI
- [ ] Basic backup to server

### Not in MVP
- Auto WhatsApp scheduling (Business API)
- Expenses, inventory, staff roles
- Multi-device, PDF reports
- Voice entry

### MVP Success Metrics
- 20 shops using weekly
- Avg 10+ entries/day per shop
- 30% of reminders lead to payment within 3 days

---

## 5. Screens (All Pages)

### 5.1 Onboarding
1. **Splash** – logo, tagline
2. **Language Select** – Tamil / English
3. **Intro Slides** (3) – Kadan track, Sales track, WhatsApp reminder
4. **Login** – mobile number
5. **OTP Verify**
6. **Shop Setup** – shop name, owner name, type, address

### 5.2 Main (Bottom Navigation)
7. **Home / Dashboard**
   - Total To Receive (big number)
   - Today's Sales / Kadan Given / Collected
   - Quick buttons: + Kadan, + Payment, + Sale
   - Overdue customers list (top 5)
8. **Customers List**
   - Search, filter, sort
   - Name, phone, balance (red = due, green = advance)
9. **Sales** (Daily)
   - Today's entries, totals
   - Calendar strip for past days
10. **Reports**
11. **Settings / Profile**

### 5.3 Customer Flow
12. **Add / Edit Customer**
13. **Customer Detail**
    - Balance card
    - Buttons: Kadan, Payment, Remind, Statement
    - Transaction history timeline
14. **Add Kadan Entry** – amount, note, date, due date, photo
15. **Add Payment Entry** – amount, mode, date
16. **Transaction Detail / Edit**
17. **Customer Statement** – preview + share

### 5.4 Sales Flow
18. **Add Sale Entry** – amount, mode (Cash/UPI/Kadan), note
19. **Day Summary** – totals, cash in hand
20. **Close Day** – opening/closing cash confirm

### 5.5 Reminders
21. **Reminder Preview** – edit Tamil message, send to WhatsApp
22. **Bulk Reminder** – select overdue customers, send one by one
23. **Reminder History**
24. **Message Templates** (edit)

### 5.6 Reports
25. **Sales Report** (daily/weekly/monthly)
26. **Kadan Outstanding Report**
27. **Collection Report**
28. **Export / Share**

### 5.7 Settings
29. **Shop Profile**
30. **Language**
31. **Security** (PIN / fingerprint)
32. **Backup & Restore**
33. **Notification Settings**
34. **About / Help / Contact Support**
35. **Subscription / Premium** (later)

---

## 6. Key User Flows

**Kadan add:** Home → + Kadan → select customer → amount → Save → (optional) WhatsApp confirm
**Payment collect:** Customer Detail → Payment → amount → Save → balance updates → receipt on WhatsApp
**Remind:** Customers → Overdue filter → Remind → preview → WhatsApp opens → Send
**Day close:** Sales → Close Day → confirm cash → summary saved

---

## 7. Data Model (Basic)

| Table | Key Fields |
|---|---|
| users | id, phone, name, language |
| shops | id, user_id, name, address, upi_id |
| customers | id, shop_id, name, phone, address, credit_limit, tag |
| transactions | id, shop_id, customer_id, type (kadan/payment), amount, mode, note, photo, date, due_date |
| sales | id, shop_id, amount, mode, note, date |
| day_closings | id, shop_id, date, opening_cash, closing_cash |
| reminders | id, customer_id, message, channel, sent_at |
| expenses | id, shop_id, category, amount, date (Phase 2) |

---

## 8. Tech Stack (Suggested)

- **Backend:** Laravel REST API, MySQL, JWT / Sanctum, queue for reminders
- **Mobile:** Flutter or React Native, SQLite for offline
- **WhatsApp:** MVP – `wa.me` deep link; Phase 2 – WhatsApp Business Cloud API
- **OTP:** MSG91 / Firebase Auth
- **Hosting:** VPS / Render / Railway; S3-compatible storage for photos

---

## 9. Monetization

- Free: up to 30 customers
- Premium (₹99–199/month): unlimited customers, auto WhatsApp reminders, PDF reports, multi-device
- Yearly plan discount

---

## 10. Roadmap

| Phase | Scope |
|---|---|
| **MVP (wk 1–6)** | Auth, customers, kadan ledger, daily sales, manual WhatsApp reminder |
| **v1.1** | PDF statements, reports, backup, notifications |
| **v1.2** | Expenses, profit view, auto reminders (Business API) |
| **v2.0** | Staff roles, inventory, voice entry, multi-shop |

---

## 11. Risks

- Shop owners low digital comfort → keep UI very simple, Tamil voice-over help
- WhatsApp API cost → start with `wa.me`
- Data trust → clear backup, PIN lock
- Competition (Khatabook, OkCredit) → differentiate with Tamil-first + local support

---

## 12. Dashboard, CRM, Masters, Categories & Extra Pages

Phase tags: **[MVP]** = version 1.0, **[P2]** = Phase 2, **[P3]** = Phase 3.

### 12.1 Dashboard

**Top cards**
- Total Baaki (to receive) [MVP]
- Innaikku Viyaabaaram (today's sales) [MVP]
- Innaikku Kadan Koduthen (credit given today) [MVP]
- Innaikku Vasool (collected today) [MVP]
- Cash in hand [MVP]
- Overdue customers count [MVP]

**Lists**
- Top 5 baaki customers [MVP]
- Overdue / due today list with one-tap Remind [MVP]
- Recent 10 transactions [MVP]
- Inactive customers (30+ days no visit) [P2]

**Charts**
- Last 7 days sales (bar) [MVP]
- Kadan vs Vasool this month (line) [P2]
- Category-wise sales (pie) [P2]
- Profit this month [P2]

**Quick actions:** + Kadan, + Payment, + Sale, + Customer, Remind All

**Filters:** Today / This week / This month / Custom date

### 12.2 CRM (Customer Relationship)

- **Customer 360 profile** [MVP]: balance, total kadan, total paid, last payment date, last purchase date, transaction timeline
- **Customer category / tag**: Regular, VIP, New, Risky, Inactive [MVP]
- **Payment behaviour score** [P2]: Nalla (pays on time), Sari (sometimes late), Risky (often late), auto-calculated from avg delay days
- **Promise-to-pay**: customer solra date (e.g. "Friday kudukkuren") + alert on that date [MVP]
- **Notes** per customer (free text) [MVP]
- **Follow-up tasks**: "call Murugan on 5th" with reminder [P2]
- **Credit limit** with warning when exceeded [MVP]
- **Reminder history** per customer [MVP]
- **Customer groups**: Neighbours, Hotel, Wholesale, Employees [P2]
- **Bulk WhatsApp** to group: Pongal/Diwali wishes, offers, new stock info [P2]
- **Birthday / festival wishes** via WhatsApp template [P3]
- **Inactive customer alert**: 30/60/90 days no purchase [P2]
- **Customer statement** PDF / image share [MVP]
- **Block credit**: stop giving kadan to risky customer (flag) [P2]
- **Referral**: customer-oda relatives / contacts [P3]

### 12.3 Master Data

| Master | Fields | Phase |
|---|---|---|
| Shop Profile | name, owner, mobile, address, logo, UPI ID, GST no (optional) | MVP |
| Customer Master | name, mobile, address, category, tags, credit limit, notes | MVP |
| Customer Category | name, color, default credit limit | MVP |
| Payment Mode | Cash, UPI, Card, Cheque, Bank (editable) | MVP |
| Reminder Template | title, Tamil/English message, variables | MVP |
| Expense Category | name (Rent, EB, Salary, Transport, Stock purchase) | P2 |
| Product / Item Master | name (Tamil + English), category, unit, selling price, stock qty | P2 |
| Product Category | name (Arisi, Paruppu, Masala, Ennai, Snacks...) | P2 |
| Unit Master | kg, g, L, ml, piece, packet, dozen | P2 |
| Supplier Master | name, mobile, address, balance payable | P2 |
| Staff Master | name, mobile, role, salary | P3 |
| Tax Master | GST % slabs | P3 |

### 12.4 Categories

- **Customer categories:** Regular, VIP, New, Wholesale, Risky, Employee
- **Product categories** (maligai kadai sample): Arisi, Paruppu, Masala, Ennai, Sakkarai/Uppu, Snacks, Soap & Home care, Vegetables, Others
- **Expense categories:** Rent, EB bill, Stock purchase, Salary, Transport, Packing, Repair, Others
- **Sales categories** (optional): Counter sale, Home delivery, Wholesale
- Each category: name, color, icon, active/inactive. Owner can add / edit / hide. Default categories auto-created at signup per shop type.

### 12.5 All Pages / Menu (Sidebar + Bottom Nav)

**Bottom nav (mobile):** Home · Customers · Sales · Reports · More

**Full menu**
1. Dashboard
2. Customers (list, add, detail, groups, tags)
3. Kadan & Payments (all transactions, add kadan, add payment)
4. Sales (daily sales, day close, calendar)
5. Reminders (pending, bulk remind, templates, history)
6. Reports (sales, baaki, collection, customer-wise, category-wise, profit [P2])
7. Expenses [P2]
8. Products & Stock [P2]
9. Suppliers & Purchases [P2]
10. Masters (customer category, payment mode, templates, product category, units, expense category)
11. Staff [P3]
12. Notifications
13. Backup & Export
14. Settings (shop profile, language, PIN lock, password change)
15. Help & Support (Tamil video tutorials, WhatsApp support)
16. Subscription / Plan [P2]
17. Trash / Restore (deleted customers & entries)
18. Audit Log (who changed what)

### 12.6 Super Admin Panel (for you, central DB)

Separate admin web app (not visible to shops).
- Shops list: name, mobile, created date, last active, status [MVP]
- Reset shop password (needed since no OTP) [MVP]
- Block / unblock shop [MVP]
- Change shop mobile number [MVP]
- Tenant DB status: created, migrated version, last backup [MVP]
- Run / retry migration for a shop [MVP]
- Usage stats: customers count, entries per day, active shops (from `shop_stats`) [P2]
- Subscription / plan management [P2]
- Support tickets / feedback list [P2]
- Broadcast message / announcement [P3]

### 12.7 New Tables (Tenant DB `store_{id}`)

| Table | Key fields |
|---|---|
| customer_categories | id, uuid, name, color, default_credit_limit, is_active |
| customer_tags / customer_tag_map | tag name, customer_id |
| customer_notes | customer_id, note, created_at |
| promises | customer_id, amount, promise_date, status |
| follow_ups | customer_id, task, due_date, status |
| payment_modes | id, name, is_active |
| reminder_templates | id, title, body_ta, body_en |
| product_categories | id, name, color |
| units | id, name, short_name |
| products | id, name_ta, name_en, category_id, unit_id, price, stock_qty |
| expense_categories | id, name |
| expenses | id, category_id, amount, date, note |
| suppliers | id, name, mobile, address |
| audit_logs | id, entity, entity_id, action, old_value, new_value, created_at |

Central DB additions: `admins`, `shop_stats`, `support_tickets` [P2].

### 12.8 Updated MVP (adds)

- Dashboard cards + top baaki + overdue list + 7-day sales chart
- Customer categories + tags + notes + credit limit
- Promise-to-pay date
- Payment mode master + reminder templates
- Default categories auto-seeded at signup
- Trash/restore + audit log
- Super admin: shops list, reset password, block, retry migration

---

## 13. ERP Features (Phase 2 / 3)

> **Rule:** MVP = kadan + sales + CRM basics only. ERP modules are built AFTER the pilot proves shops use the app daily. Build module by module, each optional (shop owner can turn on/off in Settings).

### 13.1 Inventory / Stock [P2]
- Product master (Tamil + English name, category, unit, barcode, HSN)
- Opening stock entry
- Stock in (purchase) / stock out (sale) auto update
- Current stock list with value
- Low stock alert (min qty per product)
- Stock adjustment (damage, expiry, loss) with reason
- Batch / expiry date tracking (medical, grocery)
- Multiple units + conversion (1 bag = 25 kg)
- Stock ledger per product (every in/out)
- Dead stock report (not sold 60+ days)
- Barcode scan via phone camera [P3]

### 13.2 Purchase & Suppliers [P2]
- Supplier master (name, mobile, address, GST)
- Purchase entry (items, qty, rate, total, bill photo)
- Supplier payable (naan evlo kodukkanum) = supplier-side kadan ledger
- Pay supplier (cash / UPI), partial payments
- Purchase return
- Supplier statement + WhatsApp reminder to self (due dates)
- Purchase price history per product
- Purchase order (PO) [P3]

### 13.3 Billing / POS [P2]
- Quick bill: select products, qty, discount, total
- Payment split: cash / UPI / kadan (credit to customer)
- Bill number series (per day / per year)
- Bill print: thermal 58mm / 80mm, A4, PDF
- Share bill on WhatsApp (image / PDF link)
- Sales return / credit note
- Hold bill / resume bill
- Discount (%, flat), round-off
- GST invoice (CGST/SGST/IGST), HSN, tax summary [P3]
- Estimate / quotation [P3]
- UPI QR on bill (shop UPI ID)
- Home delivery order with address + delivery status [P3]

### 13.4 Accounting [P2]
- Cash book (daily cash in / out)
- Day book (all transactions of the day)
- Bank / UPI account book
- Expense entry with category
- Income other than sales
- Profit & Loss (daily / monthly): sales − purchase cost − expenses
- Gross margin per product / category
- Receivables (customer baaki) vs Payables (supplier baaki) summary
- Balance sheet (simple) [P3]
- Tally / Excel export for CA [P3]

### 13.5 Staff / HR [P3]
- Staff master, role, salary
- Daily attendance (present / absent / half-day)
- Salary calculation, advance, deductions
- Salary payment entry (auto expense)
- Staff-wise sales / collection

### 13.6 Roles & Permissions [P3]
- Owner, Manager, Cashier, Viewer
- Per-module permission (cashier can bill, cannot see profit)
- Staff login (own mobile + password) inside same `store_{id}` DB
- Activity log per user
- Edit/delete approval by owner

### 13.7 Multi-Shop / Branches [P3]
- One owner, many shops (each = separate `store_{id}` DB)
- Switch shop in app
- Combined dashboard across shops
- Stock transfer between branches
- Branch-wise reports

### 13.8 Reports (ERP) [P2/P3]
- Sales: daily / monthly, product-wise, category-wise, customer-wise, staff-wise
- Purchase: supplier-wise, product-wise
- Stock: current stock, low stock, stock value, dead stock, expiry
- Profit: product-wise, category-wise, monthly P&L
- Baaki: customer ageing (0–30, 31–60, 60+ days)
- Payable: supplier ageing
- GST: GSTR-1 style summary, tax collected / paid [P3]
- Export: PDF, Excel, share on WhatsApp

### 13.9 Automation & Integrations [P3]
- Auto WhatsApp reminders (Business API, scheduled)
- Auto day-close summary to owner's WhatsApp every night
- UPI payment link / QR with auto-match
- SMS fallback reminders
- Google Drive backup
- Tally export, Excel import (customers, products)
- Webhooks / public API for other tools

### 13.10 Platform / SaaS [P2/P3]
- Subscription plans: Free, Premium, Business
- Plan limits (customers, products, staff, shops)
- Payment gateway (Razorpay) for subscription
- Tamil + English invoices
- Referral program (shop refers another shop)
- In-app announcements from super admin

### 13.11 ERP Tables (Tenant DB `store_{id}`)

| Table | Key fields |
|---|---|
| stock_movements | id, uuid, product_id, type (in/out/adjust), qty, rate, ref_type, ref_id, date |
| purchases / purchase_items | supplier_id, bill_no, date, total, paid, items (product, qty, rate) |
| supplier_payments | supplier_id, amount, mode, date |
| invoices / invoice_items | customer_id, bill_no, date, subtotal, discount, tax, total, paid, items |
| sales_returns | invoice_id, items, amount, reason |
| stock_adjustments | product_id, qty, reason, date |
| batches | product_id, batch_no, expiry_date, qty |
| cash_book | date, type (in/out), amount, ref_type, ref_id, note |
| staff / attendance / salaries | staff_id, date, status, amount |
| roles / permissions / user_roles | role, module, can_view/create/edit/delete |
| shop_users | id, name, mobile, password, role_id |
| branches (central) | owner_id, shop_id |

### 13.12 Build Order (after MVP)

| Phase | Modules |
|---|---|
| **P2-a** | Products + categories + units, expenses, cash book, simple P&L |
| **P2-b** | Billing (quick bill, share on WhatsApp, print) + stock auto update |
| **P2-c** | Suppliers + purchases + payables |
| **P2-d** | Low stock alerts, ageing reports, Business API reminders, subscription |
| **P3-a** | GST billing, batch/expiry, barcode |
| **P3-b** | Staff, roles, permissions |
| **P3-c** | Multi-shop, branch reports, integrations |
